# LocalEconomy SuperApp (Demo Starter)

A WordPress plugin that helps communities by:
- Sharing transport routes between farmers, traders, and drivers.
- Posting and viewing market commodity prices.

## Features
- Custom Post Types: Routes and Market Prices
- Shortcodes: [le_routes], [le_price_index]
- Auto-creates demo pages on activation

## Installation
1. Download the ZIP
2. In WordPress Admin → Plugins → Add New → Upload Plugin
3. Choose ZIP and click Install → Activate

Pages created:
- /routes
- /price-index
