<?php
/**
 * Plugin Name: LocalEconomy SuperApp (Demo Starter)
 * Description: Community logistics + price index demo plugin. Provides Routes and Market Prices custom post types.
 * Version: 0.1.0
 * Author: Selian
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// Register Custom Post Types
function le_register_cpts() {
    register_post_type('route', [
        'label' => 'Routes',
        'public' => true,
        'show_in_menu' => true,
        'supports' => ['title','editor','custom-fields'],
    ]);
    register_post_type('market_price', [
        'label' => 'Market Prices',
        'public' => true,
        'show_in_menu' => true,
        'supports' => ['title','editor','custom-fields'],
    ]);
}
add_action('init', 'le_register_cpts');

// Shortcode for Routes
function le_routes_shortcode() {
    $q = new WP_Query(['post_type'=>'route','posts_per_page'=>10]);
    $out = "<h2>Available Routes</h2><ul>";
    while($q->have_posts()): $q->the_post();
        $out .= "<li><a href='".get_permalink()."'>".get_the_title()."</a></li>";
    endwhile; wp_reset_postdata();
    $out .= "</ul>";
    return $out;
}
add_shortcode('le_routes', 'le_routes_shortcode');

// Shortcode for Market Prices
function le_price_index_shortcode() {
    $q = new WP_Query(['post_type'=>'market_price','posts_per_page'=>10]);
    $out = "<h2>Market Prices</h2><ul>";
    while($q->have_posts()): $q->the_post();
        $out .= "<li><strong>".get_the_title()."</strong>: ".get_the_content()."</li>";
    endwhile; wp_reset_postdata();
    $out .= "</ul>";
    return $out;
}
add_shortcode('le_price_index', 'le_price_index_shortcode');

// Activation hook – create demo pages
function le_activate() {
    $routes_page = array(
        'post_title'   => 'Routes',
        'post_content' => '[le_routes]',
        'post_status'  => 'publish',
        'post_type'    => 'page'
    );
    $price_page = array(
        'post_title'   => 'Price Index',
        'post_content' => '[le_price_index]',
        'post_status'  => 'publish',
        'post_type'    => 'page'
    );
    if (!get_page_by_title('Routes')) wp_insert_post($routes_page);
    if (!get_page_by_title('Price Index')) wp_insert_post($price_page);
}
register_activation_hook(__FILE__, 'le_activate');
?>
